/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class HelloGoodbye
{
public static void main(String[] args) {
System.out.println("Hello " + args[0] + " and " + args[1] + ".");
System.out.println("Goodbye " + args[1] + " and " + args[0] + ".");
}
}
